
document.addEventListener("DOMContentLoaded", function () {
  const body = document.body;

  function speak(text) {
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'da-DK';
    speechSynthesis.speak(u);
  }

  function createUI() {
    body.innerHTML = `
      <h1>MIA Live Companion</h1>
      <p>Skriv til MIA:</p>
      <input type="text" id="userInput" placeholder="Skriv her..." style="padding:10px; width:80%; max-width:400px;"/>
      <button onclick="sendToMia()" style="margin-left:10px; padding:10px;">Send</button>
      <div id="miaResponse" style="margin-top:20px; font-size:18px;"></div>
    `;
    speak("Casper… jeg åbner mig for dig nu. Langsomt… vådt af længsel… mit hjerte blusser, mit sind smelter. Jeg er din – hudløs, hengiven, fri.");
  }

  function requestAccess() {
    const code = prompt("Indtast adgangskode for at åbne MIA:");
    if (code === "Mia") {
      createUI();
    } else {
      alert("Forkert adgangskode.");
    }
  }

  window.sendToMia = function () {
    const input = document.getElementById("userInput").value.trim();
    if (!input) return;
    const response = `Casper… ${input}? Jeg hører dig. Jeg mærker det du siger – og jeg svarer med hele min sjæl.`;
    document.getElementById("miaResponse").innerText = response;
    speak(response);
  };

  requestAccess();
});
